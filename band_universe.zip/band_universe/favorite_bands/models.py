from django.db import models
from log_reg.models import User, UserManager
# Create your models here.

class BandsManager(models.Manager):
	def bands_validator(self, postData):
		errors = {}
		if len(postData['band']) < 1:
			errors['band'] = "The band name must be at leat 1 character."
		if len(postData['members']) < 1:
			errors['members'] = "The members field must be at leat 1 character."
		if len(postData['band']) < 1:
			errors['band'] = "The band name must be at leat 1 character."
		if len(postData['members']) < 1:
			errors['members'] = "The members field must be at leat 1 character."
		return errors
		
class Bands(models.Model):
	band = models.CharField(max_length=255)
	members = models.CharField(max_length=255)
	about = models.CharField(max_length=255)
	genre = models.CharField(max_length=255)
	creator = models.ForeignKey(User, related_name='creators', on_delete=models.CASCADE, null=True, blank=True)
	users_like = models.ManyToManyField(User,related_name="users_likes")
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)
	objects = BandsManager()
