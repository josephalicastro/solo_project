from django.apps import AppConfig


class FavoriteBandsConfig(AppConfig):
    name = 'favorite_bands'
