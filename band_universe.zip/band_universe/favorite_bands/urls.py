from django.urls import path
from . import views

urlpatterns = [
	path('', views.dashboard),
	path('user/logout', views.logout),
	path('create_band', views.create_band),
	path('created_band', views.created_band),
	path('created_band/edit/<int:id>', views.edit),
	path('created_band/update/<int:id>', views.update),
	path('created_band/remove/<int:id>', views.remove),
	path('created_band/view/<int:id>', views.view),
	path('created_band/like/<int:id>', views.like)
]