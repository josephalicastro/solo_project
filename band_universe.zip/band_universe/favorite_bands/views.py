from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, UserManager, Bands, BandsManager
# Create your views here.

def dashboard(request):
	context = {
		'user': User.objects.get(id=request.session['log_user_id']),
		'users': User.objects.all()
	}
	return render(request, 'dashboard.html', context)

def logout(request):
	request.session.clear()
	return redirect('/')

def create_band(request):
	return render(request, 'create_band.html')

def created_band(request):
	if request.method == "POST":
		errors = Bands.objects.bands_validator(request.POST)
		if len(errors) > 0:
			for key, value in errors.items():
				messages.error(request, value, extra_tags=key)
			return redirect('/create_band')
		user = User.objects.get(id=request.session['log_user_id'])
		new_band = Bands.objects.create(
			band = request.POST['band'],
			members = request.POST['members'],
			about = request.POST['about'],
			genre = request.POST['genre'],
			creator = user
			)
		context = {
			'user': User.objects.get(id=request.session['log_user_id']),
			'bands': Bands.objects.all()
		}   
		return render(request, 'created_band.html', context)
	context = {
		'user': User.objects.get(id=request.session['log_user_id']),
		'bands': Bands.objects.all()
	}   
	return render(request, 'created_band.html', context)
	
def edit(request, id):
	context = {
	'user': User.objects.get(id=request.session['log_user_id']),
	'band': Bands.objects.get(id=id)
	}   
	return render(request, 'band_edit.html', context)

def update(request, id):
	if request.method == "POST":
		errors = Bands.objects.bands_validator(request.POST)
		if len(errors) > 0:
			for key, value in errors.items():
				messages.error(request, value, extra_tags=key)
			return redirect(f'/created_band/edit/{id}')
		else:
			to_update = Bands.objects.get(id=id)

			to_update.band = request.POST['band']
			to_update.members = request.POST['members']
			to_update.about = request.POST['about']
			to_update.genre = request.POST['genre']
			to_update.save()

			return redirect('/favorite_bands')

def remove(request, id):
	to_delete = Bands.objects.get(id=id)

	to_delete.delete()
	return redirect('/favorite_bands')

def view(request, id):
	context = {
	'user': User.objects.get(id=id),
	'bands': Bands.objects.all()
	}
	return render(request,'created_band.html', context)

def like(request, id):
	band_like = Bands.objects.get(id=id)
	user = User.objects.get(id=request.session['log_user_id'])
	band_like.users_like.add(user)

	return redirect('/favorite_bands')
