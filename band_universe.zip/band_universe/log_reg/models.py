from django.db import models
import re
import bcrypt

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class UserManager(models.Manager):
	def user_validator(self, postData):
		errors = {}
		if len(postData['user']) < 2:
			errors['user'] = "Member name must be 2 characters or more"
		if not EMAIL_REGEX.match(postData['email']):
			errors['email'] = "Invalid email address!"
		if len(postData['password']) < 8:
			errors['password'] = "Password must be 8 characters or more"
		if postData['password'] != postData['confirm_password']:
			errors['password'] = "Passwords do not match"
		return errors

class User(models.Model):
	user = models.CharField(max_length=255)
	email = models.CharField(max_length=255)
	password = models.CharField(max_length=255)
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)
	objects = UserManager()