from django.apps import AppConfig


class LogRegConfig(AppConfig):
    name = 'log_reg'
